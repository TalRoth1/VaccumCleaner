package bgu.spl.mics.application.objects;

/**
 * Represents a landmark in the environment map.
 * Landmarks are identified and updated by the FusionSlam service.
 */
public class LandMark {

    public LandMark(String id, String description, double[] transformedCoordinates) {
        //TODO Auto-generated constructor stub
    }

    public void updateCoordinates(double[] transformedCoordinates) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'updateCoordinates'");
    }
    // TODO: Define fields and methods.
}
